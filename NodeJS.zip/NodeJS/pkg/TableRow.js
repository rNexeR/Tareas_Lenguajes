function TableRow(from, to, weight, flag){
	this.from = from;
	this.to = to;
	this.weight = weight;
	this.flag = flag;
}

module.exports = TableRow;

